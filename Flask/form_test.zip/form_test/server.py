from flask import Flask, render_template, request, redirect
app = Flask(__name__)
# our index route will handle rendering our form


@app.route('/')
def index():
    return render_template("index.html")
# this route will handle our form submission
# notice how we defined which HTTP methods are allowed by this route

# global formName
# formLoc = ""
# formLang = ""
# formComment = ""


@app.route('/users', methods=['POST'])
def create_user():
    print "Got Post Info"
    # we'll talk about the following two lines after we learn a little more
    # about forms
    global formName
    formName = request.form['name']
    global formLoc
    formLoc = request.form['location']
    global formLang
    formLang = request.form['language']
    global formComment
    formComment = request.form['comment']
    print formName
    print formLoc
    print formLang
    print formComment
    return redirect('/result')


@app.route('/result')
def result():
    return render_template("result.html", name=formName, location=formLoc, language=formLang, comment=formComment)
    if request.method == 'POST':
        if request.form['submit'] == 'back':
            return redirect('/')
app.run(debug=True)  # run our server
